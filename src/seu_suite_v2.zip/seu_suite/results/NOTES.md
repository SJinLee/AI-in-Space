# SEU suite — paper_sweep notes

## Physics / time ASSUMPTIONS (not wall-clock)

- True SEU = XOR of one random bit of a float32 weight (uint32 view). **Not** Gaussian noise.

- Default rate `r = 1e-6` SEU/bit/day. `λ = r * N_bits * Δt_days`.

- Inference exposure **T = 1.0 LEO day** (also `--T saa_pass` = 12/1440 day).

- Training uses `--train-hours 24` so the **entire training run is mapped to 1.0 satellite day**.
  This is an ASSUMPTION so λ is nontrivial. A 2-second Colab train is **not** a real satellite wall-clock.

- `leo_saa`: 3 SAA passes × 12 min / day; ~90% of expected daily SEUs in those passes
  (`r_saa ≈ 36 r_avg`), remainder in quiet time.

- `stress`: ignore physical r; each weight independently hit with probability p=0.01 (course accelerator).

- Only weight tensors with dim ≥ 2 are flipped (no biases unless `--flip-bias`).


## N_bits per model (weight tensors only)

- **toy50**: N_weights=50  N_bits=1,600  λ(1 day, r=1e-6)≈0.0016

- **mnist_linear**: N_weights=101,632  N_bits=3,252,224  λ(1 day, r=1e-6)≈3.252

- **mnist_cnn**: N_weights=220,064  N_bits=7,042,048  λ(1 day, r=1e-6)≈7.042

- **resnet18_t10**: N_weights=11,172,032  N_bits=357,505,024  λ(1 day, r=1e-6)≈357.5

- **cifar_deep**: N_weights=307,040  N_bits=9,825,280  λ(1 day, r=1e-6)≈9.825


## resnet18_t10 variant

`pretrained_fc_32x32_no_upscale`

Input is 32×32; images are **not** upscaled to 224.


## What ran / pilot decisions

- cifar_deep: epochs=1 n_train=10000 n_test=2000 train_1ep=6.65s infer=0.43s clean_acc=51.95%

- mnist_cnn: epochs=2 n_train=60000 n_test=10000 train_1ep=9.07s infer=1.01s clean_acc=98.78%

- mnist_linear: epochs=2 n_train=60000 n_test=10000 train_1ep=0.53s infer=0.01s clean_acc=96.66%

- resnet18_t10: epochs=1 n_train=10000 n_test=2000 train_1ep=6.43s infer=0.62s clean_acc=39.10%

- toy50: epochs=8 n_train=2000 n_test=500 train_1ep=0.01s infer=0.00s clean_acc=91.80%


## Timings (seconds)

- pilot_train_1ep_cifar_deep: 6.645s

- pilot_infer_cifar_deep: 0.426s

- pilot_train_1ep_mnist_cnn: 9.072s

- pilot_infer_mnist_cnn: 1.010s

- pilot_train_1ep_mnist_linear: 0.528s

- pilot_infer_mnist_linear: 0.008s

- pilot_train_1ep_resnet18_t10: 6.432s

- pilot_infer_resnet18_t10: 0.616s

- pilot_train_1ep_toy50: 0.010s

- pilot_infer_toy50: 0.001s


- **total wall**: 535.8s (8.9 min)


## Ensemble training

Logit-average ensemble during training is implemented only for ['mnist_linear', 'toy50'].
 CNN / ResNet ensemble is inference-only.


## Summary table


       model  mode     rad  defense  n  mean_acc  std_acc  crash_rate      mean_k    n_bits  mean_seconds  T_days
  cifar_deep infer leo_saa     clip  3   51.9333   0.0289      0.0000     11.6667   9825280        0.6252  1.0000
  cifar_deep infer leo_saa     none  3   50.3833   2.7135      0.0000      5.6667   9825280        0.6548  1.0000
  cifar_deep infer  stress     clip  3   29.5833   4.7761      0.0000   3138.3333   9825280        0.6670  1.0000
  cifar_deep infer  stress     none  3   10.0000   0.0000      1.0000   3068.0000   9825280        0.1079  1.0000
  cifar_deep train leo_saa     clip  2   26.4000   0.0707      0.0000     10.0000   9825280        6.7037  1.0000
  cifar_deep train leo_saa     none  2   30.7750   2.5102      0.0000     12.0000   9825280        6.6451  1.0000
   mnist_cnn infer leo_saa     clip  5   98.7800   0.0000      0.0000      6.0000   7042048        1.0994  1.0000
   mnist_cnn infer leo_saa     none  5   86.3760  27.7362      0.0000      3.8000   7042048        1.0637  1.0000
   mnist_cnn infer  stress     clip  5   97.3980   1.0280      0.0000   2240.2000   7042048        1.0748  1.0000
   mnist_cnn infer  stress     none  5   10.9480   2.1198      0.8000   2239.2000   7042048        0.2977  1.0000
   mnist_cnn train leo_saa     clip  5   98.6580   0.1052      0.0000      5.2000   7042048       16.0450  1.0000
   mnist_cnn train leo_saa     none  5   98.8040   0.0876      0.0000      7.8000   7042048       15.9073  1.0000
   mnist_cnn train  stress     clip  5   98.6380   0.1789      0.0000   2187.2000   7042048       15.9694  1.0000
   mnist_cnn train  stress     none  5   10.0000   0.0000      1.0000     88.6000   7042048        0.6147  1.0000
mnist_linear infer leo_saa     clip  8   96.6600   0.0000      0.0000      3.0000   3252224        0.0076  1.0000
mnist_linear infer leo_saa     none  8   96.6587   0.0035      0.0000      2.5000   3252224        0.0085  1.0000
mnist_linear infer leo_saa      tmr  8   96.6600   0.0000      0.0000      3.5417   3252224        0.0120  1.0000
mnist_linear infer poisson     clip  8   96.6550   0.0141      0.0000      2.5000   3252224        0.0071  1.0000
mnist_linear infer poisson     none  8   95.4925   3.2580      0.0000      4.0000   3252224        0.0071  1.0000
mnist_linear infer poisson      tmr  8   96.6600   0.0000      0.0000      3.2500   3252224        0.0110  1.0000
mnist_linear infer  stress     clip  8   94.7950   1.4737      0.0000   1029.5000   3252224        0.0132  1.0000
mnist_linear infer  stress     none  8   12.6700   4.2265      0.1250   1009.1250   3252224        0.0132  1.0000
mnist_linear infer  stress      tmr  8   96.6600   0.0053      0.0000   1017.1667   3252224        0.0276  1.0000
mnist_linear train leo_saa     clip  8   96.3912   0.2168      0.0000      3.3750   3252224        0.9148  1.0000
mnist_linear train leo_saa     none  8   96.4300   0.1602      0.0000      2.7500   3252224        0.9410  1.0000
mnist_linear train leo_saa      tmr  8   96.3413   0.1690      0.0000      3.5000   3252224        0.8986  1.0000
mnist_linear train poisson     clip  8   96.2750   0.1342      0.0000      2.2500   3252224        0.8877  1.0000
mnist_linear train poisson     none  8   96.4125   0.1777      0.0000      3.5000   3252224        0.8903  1.0000
mnist_linear train poisson      tmr  8   96.3625   0.1450      0.0000      3.5000   3252224        0.9020  1.0000
mnist_linear train  stress     clip  8   96.1525   0.3074      0.0000   1027.6250   3252224        1.0282  1.0000
mnist_linear train  stress     none  8   19.9612  28.1747      1.0000    102.8750   3252224        0.1049  1.0000
mnist_linear train  stress      tmr  8   96.4363   0.1282      0.0000   1017.8750   3252224        1.8398  1.0000
resnet18_t10 infer leo_saa     clip  3   38.2167   0.4010      0.0000    355.3333 357505024        0.6052  1.0000
resnet18_t10 infer leo_saa     none  3   23.7333  11.9538      0.3333    367.0000 357505024        0.5307  1.0000
resnet18_t10 infer  stress     clip  3   10.2167   0.4646      0.0000 111440.6667 357505024        1.2722  1.0000
resnet18_t10 infer  stress     none  3   10.0000   0.0000      1.0000 111716.0000 357505024        0.9665  1.0000
resnet18_t10 train leo_saa     clip  2   36.7500   1.0607      0.0000    352.0000 357505024        6.7441  1.0000
resnet18_t10 train leo_saa     none  2   36.4500   0.7778      0.0000    342.5000 357505024        6.2362  1.0000
resnet18_t10 train  stress     clip  2   25.4500   0.6364      0.0000 111958.5000 357505024        7.6131  1.0000
resnet18_t10 train  stress     none  2   17.6750  11.2076      0.5000  56329.0000 357505024        3.9426  1.0000
       toy50 infer leo_saa     clip 15  100.0000   0.0000      0.0000      0.0000      1600        0.0009  1.0000
       toy50 infer leo_saa ensemble 15  100.0000   0.0000      0.0000      0.0000      1600        0.0019  1.0000
       toy50 infer leo_saa     none 15  100.0000   0.0000      0.0000      0.0000      1600        0.0008  1.0000
       toy50 infer leo_saa   parity 15  100.0000   0.0000      0.0000      0.0000      1600        0.0010  1.0000
       toy50 infer leo_saa      tmr 15  100.0000   0.0000      0.0000      0.0000      1600        0.0016  1.0000
       toy50 infer poisson     clip 15  100.0000   0.0000      0.0000      0.0000      1600        0.0008  1.0000
       toy50 infer poisson ensemble 15  100.0000   0.0000      0.0000      0.0000      1600        0.0017  1.0000
       toy50 infer poisson     none 15  100.0000   0.0000      0.0000      0.0000      1600        0.0008  1.0000
       toy50 infer poisson   parity 15  100.0000   0.0000      0.0000      0.0000      1600        0.0009  1.0000
       toy50 infer poisson      tmr 15  100.0000   0.0000      0.0000      0.0000      1600        0.0015  1.0000
       toy50 infer  stress     clip 15   98.6400   5.2673      0.0000      0.3333      1600        0.0009  1.0000
       toy50 infer  stress ensemble 15   96.4933  11.5612      0.0000      0.3867      1600        0.0019  1.0000
       toy50 infer  stress     none 15   99.2533   2.0818      0.0000      0.3333      1600        0.0009  1.0000
       toy50 infer  stress   parity 15   99.4267   1.6438      0.0000      0.2667      1600        0.0009  1.0000
       toy50 infer  stress      tmr 15  100.0000   0.0000      0.0000      0.5556      1600        0.0016  1.0000
       toy50 train leo_saa     clip 15   89.1067   1.8729      0.0000      0.0000      1600        0.0500  1.0000
       toy50 train leo_saa ensemble 15   91.7200   1.2802      0.0000      0.0000      1600        0.1476  1.0000
       toy50 train leo_saa     none 15   88.6533   2.0276      0.0000      0.0000      1600        0.0504  1.0000
       toy50 train leo_saa   parity 15   88.5600   2.0399      0.0000      0.0000      1600        0.0600  1.0000
       toy50 train leo_saa      tmr 15   88.1333   2.4398      0.0000      0.0000      1600        0.0503  1.0000
       toy50 train poisson     clip 15   87.8933   1.7102      0.0000      0.0000      1600        0.0490  1.0000
       toy50 train poisson ensemble 15   92.1600   1.3054      0.0000      0.0000      1600        0.1461  1.0000
       toy50 train poisson     none 15   88.2933   1.8514      0.0000      0.0667      1600        0.0486  1.0000
       toy50 train poisson   parity 15   88.3867   1.7768      0.0000      0.0000      1600        0.0649  1.0000
       toy50 train poisson      tmr 15   88.3200   1.9911      0.0000      0.0000      1600        0.0483  1.0000
       toy50 train  stress     clip 15   88.3867   2.2872      0.0000      0.6667      1600        0.0488  1.0000
       toy50 train  stress ensemble 15   92.0533   1.7655      0.0000      0.5111      1600        0.1547  1.0000
       toy50 train  stress     none 15   88.7200   1.8218      0.0000      0.3333      1600        0.0485  1.0000
       toy50 train  stress   parity 15   88.8533   2.0459      0.0000      0.2667      1600        0.0694  1.0000
       toy50 train  stress      tmr 15   89.3333   1.6847      0.0000      0.4000      1600        0.0498  1.0000



Raw trials: 670
